module.exports = {
    runtimeCompiler: true //You will bump into following error if you use template in non .vue file,  https://code.luasoftware.com/tutorials/vuejs/vue-cli-3-include-runtime-compiler/
}