 <template>
    <section if="survey">
        <h2>Survey Page</h2>
        {{this.survey}}
        <form @submit.prevent="save">
            <!-- <select-box v-for="(cmp, i) in survey.cmps" v-bind:key="i" :info="cmp.info" @setVal="setAns"></select-box> -->
            <component :is="cmp.type" v-for="(cmp, idx) in survey.cmps" v-bind:key="idx" :info="cmp.info" @setVal="setAns($event, idx)" >
            </component>
            <!-- <select-box ></select-box> -->
            <button>Save</button>
        </form>
        <pre>
            {{answer}}
        </pre>
    </section>
</template>

<script>
//import selectBox from '../components/select-box.cmp.js'
import selectBox from '../components/select-box.cmp'
import textBox from '../components/text-box.cmp'
import linearScale  from '../components/linear-scale.cmp'
import surveyService from '../survey.service'
export default {
    name: 'Survey',
    methods: {
        save() {console.log('Saving......')
        },
        setAns(ans, idx) {
            console.log('Setting the answer: ', ans)
            this.answer.splice(idx, 1, ans)
        },
    },
    data() {
        return {
            survey: null,
            answer: [] 
        }
    },
    created() {
        this.survey= surveyService.getById()
        this.answer = new Array(this.survey.cmps.length)
    },

    components: {
        selectBox,
        textBox,
        linearScale
    }
}
</script>