<template>
    <section>
        <h1> Home Page</h1>
    </section>
</template>

<script>
export default {
    name: 'Home',
}
</script>