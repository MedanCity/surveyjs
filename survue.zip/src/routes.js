
import HelloWorld from './components/HelloWorld.vue'
import Home from './pages/home.vue'
import Survey from './pages/survey.vue'

// const route= new VueRouter({
//     routes: [
//       { path: '/', component: HelloWorld}  ,
//       { path: '/Home', component: Home}  ,
//       { path: '/Survey', component: Survey}  ,
//     ],
//   })


const route = [
    { path: '/', component: HelloWorld}  ,
    { path: '/home', component: Home}  ,
    { path: '/survey', component: Survey}  ,
]
export default route