export default {
    getById
}
function getById() {
    return survey;
}

var survey= {
    title: 'Robot Shopping',
    cmps: [
        {
            type:"select-box",
            info: {
                id:1,
                label: 'How was your shopping?',
                opts:['Great', 'Good', 'Bad']
            }
        },{
            type:"select-box",
            info: {
                id:2,
                label: 'What is your score?',
                opts:['10', '6', 'Bad']
            },
        },{
            type:"text-box",
            info: {
                id:3,
                label: 'What is your name?',
                //opts:['10', '6', 'Bad']
            },
        },{
            type:"textBox",
            info: {
                id:4,
                label: 'Robot Type ?',
                opts:['CleanDude', 'FeedMeBox', 'misterPleasure']
            },
        },{
            type:"linearScale",
            info: {
                id:5,
                label: 'Quality ?',
                max: 5
            },
        }
    ]
}