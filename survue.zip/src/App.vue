<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <h1>Hello App!</h1>
    <nav>
      <!-- use router-link component for navigation. -->
      <!-- specify the link by passing the `to` prop. -->
      <!-- <router-link> will be rendered as an `<a>` tag by default -->
      <router-link to="/">Go to Helloworld</router-link>
      <router-link to="/home">Go to Home</router-link>
      <router-link to="/survey">Go to Survey</router-link>
    </nav>
    <!-- route outlet -->
    <!-- component matched by the route will render here -->
    <router-view id="view"></router-view>

  </div>
</template>

<script>
import VueRouter  from 'vue-router'
import routes from './routes.js'  //name should plural, singular can't show the view

const router= new VueRouter({routes})

// const route = [
//   { path: '/', component: HelloWorld}  ,
//   { path: '/Home', component: Home}  ,
//   { path: '/Survey', component: Survey}  ,
// ]
// const router= new VueRouter({route})

// const router= new VueRouter({
//   routes: [
//     { path: '/', component: HelloWorld}  ,
//     { path: '/Home', component: Home}  ,
//     { path: '/Survey', component: Survey}  ,
//   ],
// })

export default {
  name: 'App',
  router: router,
  // router: new VueRouter({
  //   routes: [
  //     { path: '/', component: HelloWorld}  ,
  //     { path: '/Home', component: Home}  ,
  //     { path: '/Survey', component: Survey}  
  //   ]
  // }),
  components: {
    //HelloWorld, 
    //Home,
    //Survey,
  }
}

</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
